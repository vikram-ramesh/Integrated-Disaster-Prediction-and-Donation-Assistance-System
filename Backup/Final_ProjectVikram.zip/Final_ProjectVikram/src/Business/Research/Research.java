/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Research;

/**
 *
 * @author vikram
 */
public class Research {
    private String emergency;

    public String getEmergency() {
        return emergency;
    }

    public void setEmergency(String emergency) {
        this.emergency = emergency;
    }
    
    @Override
    public String toString()
    {
        return emergency;
                
    }
    
}
